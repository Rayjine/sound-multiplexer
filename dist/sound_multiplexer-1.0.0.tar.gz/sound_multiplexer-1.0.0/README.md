# 🎵 Sound Multiplexer

A modern Linux audio multiplexer with GUI interface that allows you to play audio simultaneously through multiple output devices with advanced synchronization and theming capabilities.

## ✨ Features

### 🔊 **Multi-Device Audio Output**
- **Simultaneous Playback**: Route audio to multiple devices at once (speakers + headphones + Bluetooth, etc.)
- **Device Selection**: Easy checkbox interface to enable/disable individual audio outputs
- **True Silence Mode**: Complete audio silence when no devices are selected (no fallback to system default)
- **Real-time Device Detection**: Automatic detection of plugged/unplugged audio devices

### 🎚️ **Advanced Audio Controls**
- **Individual Volume Control**: Separate volume slider for each audio device
- **Mute Toggle**: Independent mute button for each device with visual feedback
- **System Synchronization**: Real-time sync with system audio settings (volume changes from other apps instantly reflected)
- **Sync Compensation (UI setting)**: Toggle available in Settings; advanced per-device delay is not implemented yet

### 🎨 **Modern User Interface**
- **Card-Based Design**: Clean, modern cards for each audio device with icons
- **Device Type Icons**: Automatic device type detection (🎧 headphones, 🔊 speakers, 🖥️ monitors, 🔗 Bluetooth)
- **Light/Dark Themes**: Full theme support with system detection
- **Enhanced Controls**: Large, visible checkboxes and intuitive volume controls
- **Real-time Status**: Live status updates showing active devices and silent mode

### ⚙️ **Intelligent Audio Processing**
- **PulseAudio Integration**: Deep integration with Linux PulseAudio system
- **Latency Compensation (planned)**: UI exposes a setting, but advanced per-device latency correction is not implemented yet
- **System Visibility**: Created audio sinks appear in system settings with descriptive names
- **Clean Resource Management**: Proper cleanup of audio modules on exit

## 🚀 Quick Start

### Prerequisites
- Linux with PulseAudio or PipeWire (with PulseAudio compatibility)
- Python 3.8+
- PyQt6
- pulsectl

### Installation

```bash
# Clone the repository
git clone https://github.com/rayjine/sound-multiplexer.git
cd sound-multiplexer

# Install dependencies
pip install -r requirements.txt

# Run the application
python main.py
```

### First Run
1. **Launch the application** - Audio devices will be automatically detected
2. **Select devices** - Check the boxes for devices you want to use simultaneously
3. **Adjust volumes** - Use individual volume sliders for each device
4. **Configure sync** - Open settings (⚙️) to enable/disable audio synchronization

## 📖 User Guide

### Basic Usage

#### **Selecting Audio Devices**
- **Enable devices**: Check the box next to any audio device to include it in output
- **Multiple devices**: Select as many devices as you want for simultaneous playbook
- **No devices**: Uncheck all devices for complete silence (no system fallback)

#### **Volume Control**
- **Individual volumes**: Each device has its own volume slider (0-100%)
- **Mute control**: Click the 🔊/🔇 button to mute/unmute individual devices
- **System sync**: Volume changes in system settings automatically update the interface

#### **Device Management**
- **Auto-detection**: Plug in headphones, speakers, or Bluetooth devices - they appear automatically
- **Hot-swapping**: Devices can be connected/disconnected while the app is running
- **Device icons**: Visual identification of device types (headphones, speakers, monitors, etc.)

### Advanced Features

#### **Audio Synchronization**
When using multiple device types (e.g., wired speakers + Bluetooth headphones), enable sync compensation to eliminate audio echo:

1. **Open Settings** (⚙️ button in top-right)
2. **Enable "Audio sync compensation" (experimental)** — UI setting only; per-device delay is not implemented yet
3. **Reference latencies** (for future implementation):
   - Bluetooth: ~150ms
   - HDMI/Monitor: ~8ms
   - USB Audio: ~5ms
   - Analog: ~2ms

#### **Theme Customization**
Access themes via Settings (⚙️):
- **System Default**: Automatically follows your desktop theme
- **Light Mode**: Clean interface with bright colors
- **Dark Mode**: Easy on the eyes for low-light environments

#### **Silent Mode**
When no devices are selected:
- **True silence**: Audio is completely muted (no fallback)
- **Null sink**: Creates a "black hole" for audio output
- **Visual indicator**: Status shows "Silent mode" in orange text

## 🔧 Technical Details

### Architecture

#### **Audio Processing**
- **PulseAudio Modules**: Uses `module-combine-sink` for multiple outputs
- **Null Sink**: Uses `module-null-sink` for silent mode
- **Event Monitoring**: Real-time PulseAudio event processing

#### **System Integration**
- **Device Detection**: Monitors PulseAudio sink events for plug/unplug
- **Volume Sync**: Bidirectional synchronization with system volume controls
- **Mute Sync**: Real-time mute state synchronization
- **Clean Shutdown**: Proper cleanup of all created audio modules

#### **Audio Latency Compensation**
Currently not implemented. The UI provides a "sync compensation" toggle, but no per-device delay modules are created. Estimated latencies (Bluetooth > HDMI/USB > Analog) are provided for future reference only.

### File Structure
```
sound-multiplexer/
├── main.py                     # Application entry point
├── src/
│   ├── audio_manager.py        # PulseAudio integration & device management
│   ├── theme_manager.py        # Theme system & styling
│   └── gui/
│       ├── main_window.py      # Main interface & device cards
│       └── settings_dialog.py  # Settings & preferences
├── docs/                       # Documentation
└── requirements.txt           # Python dependencies
```

## ⚙️ Configuration

### Settings Storage
Settings are automatically saved using Qt's QSettings:
- **Theme preference**: `~/.config/SoundMultiplexer/Theme.conf`
- **Audio sync setting**: `~/.config/SoundMultiplexer/AudioSync.conf`

### Audio Module Names
The application creates the following PulseAudio modules:
- **Combined sink**: `sound_multiplexer_combined` (when devices selected)
- **Null sink**: `sound_multiplexer_null` (when no devices selected)

## 🎯 Use Cases

### **Home Entertainment**
- Play music through both TV speakers and wireless headphones
- Route game audio to speakers while voice chat goes to headphones

### **Content Creation**
- Monitor audio through headphones while recording to external speakers
- Multiple monitor setups with synchronized audio

### **Accessibility**
- Simultaneous output to hearing aids and speakers
- Visual and auditory feedback through multiple devices

### **Development/Testing**
- Test audio applications across multiple device types
- Audio debugging with multiple outputs

## 🛠️ Troubleshooting

### Common Issues

#### **No audio devices detected**
- Check PulseAudio is running: `pulseaudio --check`
- Restart PulseAudio: `pulseaudio -k && pulseaudio --start`
- Check device permissions

#### **Audio stuttering with sync compensation**
- Try disabling sync compensation in settings
- Check system CPU usage during playback
- Verify PulseAudio configuration

#### **Settings not saving**
- Check write permissions for `~/.config/SoundMultiplexer/`
- Verify Qt settings are working: test with other Qt applications

#### **Bluetooth latency issues**
- Sync compensation should handle this automatically
- Try manual Bluetooth codec selection (A2DP, aptX)
- Check Bluetooth device specifications

### Debug Mode
Run with verbose output:
```bash
python main.py --debug
```

### Log Files
Application logs PulseAudio operations to console:
- Module creation/destruction
- Device detection events
- Sync compensation calculations

## 📦 Installation & Packaging

### Package Installation

#### Automated Installation
Use the provided installation script for automatic dependency installation:
```bash
# Clone the repository
git clone https://github.com/rayjine/sound-multiplexer.git
cd sound-multiplexer

# Run installation script
./packaging/install.sh
```

#### Manual Installation
For manual installation with more control:

**Fedora/RHEL/CentOS:**
```bash
# Install dependencies (Fedora 34+ uses PipeWire with PulseAudio compatibility)
sudo dnf install python3 python3-pip python3-PyQt6 pipewire-pulseaudio pulseaudio-utils

# Install Sound Multiplexer
pip3 install --user pulsectl
make install-user
```

**Ubuntu/Debian:**
```bash
# Install dependencies  
sudo apt update
sudo apt install python3 python3-pip python3-pyqt6 pulseaudio pulseaudio-utils

# Install Sound Multiplexer
pip3 install --user pulsectl
make install-user
```

**Arch Linux:**
```bash
# Install dependencies
sudo pacman -S python python-pip python-pyqt6 pulseaudio

# Install Sound Multiplexer
pip3 install --user pulsectl
make install-user
```

**openSUSE:**
```bash
# Install dependencies
sudo zypper install python3 python3-pip python3-PyQt6 pulseaudio pulseaudio-utils

# Install Sound Multiplexer
pip3 install --user pulsectl
make install-user
```

### Building Packages

#### RPM Package (Fedora/RHEL/openSUSE)
```bash
# Install build dependencies
sudo dnf install rpm-build rpmbuild

# Build RPM
make rpm

# Install the built package
sudo dnf install packaging/rpmbuild/RPMS/noarch/sound-multiplexer-*.rpm
```

#### DEB Package (Debian/Ubuntu)
```bash
# Install build dependencies
sudo apt install devscripts debhelper dh-make

# Build DEB
make deb

# Install the built package
sudo dpkg -i packaging/debian/sound-multiplexer_*.deb
```

#### Python Package (pip)
```bash
# Ensure build tooling is available (choose one):
# pip3 install --user wheel
# or
# make dev-deps

# Build wheel
make build

# Install locally
pip3 install --user dist/sound-multiplexer-*.whl
```

### Distribution Maintainers

To include Sound Multiplexer in your distribution:

1. **Dependencies:**
   - Python 3.8+
   - PyQt6
   - PulseAudio
   - python3-pulsectl (pip installable)

2. **Build files provided:**
   - `setup.py` - Standard Python packaging
   - `packaging/sound-multiplexer.spec` - RPM spec file
   - `packaging/sound-multiplexer.desktop` - Desktop entry
   - `Makefile` - Build automation

3. **Installation paths:**
   - Binary: `/usr/bin/sound-multiplexer`
   - Desktop file: `/usr/share/applications/`
   - Icon: `/usr/share/pixmaps/`
   - Documentation: `/usr/share/doc/sound-multiplexer/`

### Development Installation
```bash
# Clone and install in development mode
git clone https://github.com/rayjine/sound-multiplexer.git
cd sound-multiplexer

# Install dependencies
make deps dev-deps

# Install in development mode (editable)
make dev-install
```

## 🤝 Contributing

### Development Setup
1. Fork the repository
2. Create a virtual environment: `python -m venv venv` (optional)
3. Install development dependencies: `make dev-deps`
4. Optional: run formatting and linting: `make format lint`

### Architecture Guidelines
- **Separation of concerns**: GUI, audio management, and theming are separate modules
- **Qt signals/slots**: Use for inter-component communication
- **Error handling**: Graceful degradation when PulseAudio operations fail
- **Resource cleanup**: Always clean up PulseAudio modules

## 📄 License

This project is licensed under the GNU General Public License v3.0 - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **PulseAudio** for the flexible Linux audio system
- **PyQt6** for the modern GUI framework
- **pulsectl** for Python PulseAudio integration

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/rayjine/sound-multiplexer/issues)
- **Discussions**: [GitHub Discussions](https://github.com/rayjine/sound-multiplexer/discussions)
- **Wiki**: [Project Wiki](https://github.com/rayjine/sound-multiplexer/wiki)

---

**Made with ❤️ for the Linux audio community**

## Author

Nicolas Filimonov